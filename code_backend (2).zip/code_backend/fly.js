/*const dgram = require('dgram');
const wait = require('waait');
const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const throttle = require('lodash/throttle');
const commandDelays = require('./commandDelays');

const PORT = 8889;
const HOST = '192.168.10.1';
const drone = dgram.createSocket('udp4');
drone.bind(PORT);

function parseState(state) {
  return state
    .split(';')
    .map(x => x.split(':'))
    .reduce((data, [key, value]) => {
      data[key] = value;
      return data;
    }, {});
}

const droneState = dgram.createSocket('udp4');
droneState.bind(8890);

drone.on('message', message => {
  console.log(`🤖 : ${message}`);
  io.sockets.emit('status', message.toString());
});

function handleError(err) {
  if (err) {
    console.log('ERROR');
    console.log(err);
  }
}

const commands = ['command', 'battery?', 'takeoff', 'land'];
// const commands = ['command', 'battery?'];

const i = 0;

drone.send('command', 0, 'command'.length, PORT, HOST, handleError);

// async function go() {
//   const command = commands[i];
//   const delay = commandDelays[command];
//   console.log(`running command: ${command}`);
//   drone.send(command, 0, command.length, PORT, HOST, handleError);
//   await wait(delay);
//   i += 1;
//   if (i < commands.length) {
//     return go();
//   }
//   console.log('done!');
// }

// go();

io.on('connection', socket => {
  socket.on('command', command => {
    console.log('command Sent from browser');
    console.log(command);
    drone.send(command, 0, command.length, PORT, HOST, handleError);
  });

  socket.emit('status', 'CONNECTED');
});

droneState.on(
  'message',
  throttle(state => {
    const formattedState = parseState(state.toString());
    io.sockets.emit('dronestate', formattedState);
  }, 100)
);

http.listen(6767, () => {
  console.log('Socket io server up and running');
});*/


const dgram = require('dgram');
const wait = require('waait');
const app = require('express')();
const ws = require('ws');
const wss = new ws.Server({noServer: true});

const http = require('http');
const io = require('socket.io')(http);
const throttle = require('lodash/throttle');
const commandDelays = require('./commandDelays');

const PORT = 8889; //TELLO PORT
const HOST = '192.168.10.1'; //TELLO ADDRESS 
const video = dgram.createSocket('udp4');// UDP SERVER IPv4 FOR RECEIVING VIDEO RAW H264 ENCODED YUV420p
const port_video = 11111;//TELLO VIDEO PORT

const port_websocket = 8080; //FOR SENDING VIDEO

//OBJ TEMP INFO
let  videoBuff = [];//VIDEO BUFFER
let  counter = 0;//COUNTER FOR VIDEO BUFFER FRAMES

const drone = dgram.createSocket('udp4');
drone.bind(PORT);

const droneState = dgram.createSocket('udp4');
droneState.bind(8890);

function accept(req, res) {
  // all incoming requests must be websockets
  if (!req.headers.upgrade || req.headers.upgrade.toLowerCase() != 'websocket') {
    res.end();
    return;
  }

  // can be Connection: keep-alive, Upgrade
  if (!req.headers.connection.match(/\bupgrade\b/i)) {
    res.end();
    return;
  }

  wss.handleUpgrade(req, req.socket, Buffer.alloc(0), onConnect);
}

/*function onConnect(ws) {
  ws.send(`Hello from server`);
  ws.on('message',function (message) {
  console.log('command Sent from browser');
  try{
      const data=JSON.parse(message)
      if(data.data === "streamon")
      {
        console.log(data.data);
        drone.send(message, 0, message.length, PORT, HOST, handleError);
        setTimeout(() => ws.close(1000, "Wait!"), 5000);
        openstream();
      }
      else
      {   
        var native_code  = data.data;
        var strRawValue = native_code;
        native_code.value = "";
        var nEmptyWidth = native_code.scrollWidth;
        var nLastWrappingIndex = -1;
        for (var i = 0; i < strRawValue.length; i++) {
          var curChar = strRawValue.charAt(i);
          if (curChar == ' ' || curChar == '-' || curChar == '+')
            nLastWrappingIndex = i;
            native_code.value += curChar;
            if (native_code.scrollWidth > nEmptyWidth) {
              var buffer = "";
              if (nLastWrappingIndex >= 0) {
                for (var j = nLastWrappingIndex + 1; j < i; j++)
                  buffer += strRawValue.charAt(j);
                  nLastWrappingIndex = -1;
                }
              buffer += curChar;
              native_code.value = native_code.value.substr(0, native_code.value.length - buffer.length);
              }
            }
            native_code.value += "time.sleep(3)" + buffer; 
            drone.send(native_code+"\n time.sleep(3)",0,native_code.length,PORT,HOST,handleError);
            setTimeout(() => ws.close(1000, "Wait!"), 5000);
            console.log(native_code);
          }
        }
      catch(e){
      console.log(`Undefined data sent:${e.message}`);
      }
    });
  }*/
function onConnect(ws){
  ws.send('Hello from the server\'s end');
  ws.on('message',function (message) {
    //console.log("Command sent from the browser")
    const data_obtained=JSON.parse(message);
    /*const index=data_obtained.index;*/
    console.log("Data obtained=",data_obtained);
    const data=data_obtained.data;
    send_command_to_drone(data);
    /*let max_index=0;
    let min_index=-1;
    //console.log(data);
    for(let i=0;i<=data.index;i++){
      max_index=data.index;
    }
    separate_command(max_index,min_index,data);*/
    //console.log("Max Index=",max_index);


    //console.log("Max index=",max_index);
    //console.log("Initiating Process\n");
    //console.log(array_command)
    /*setTimeout(function(){
        for(let i=0;i<index;i++){
            setTimeout(function(x) { 
              return function() {
              drone.send(array_command[x], 0, array_command[x].length, PORT, HOST, handleError);
              setTimeout(() => ws.close(1000, "Wait!"), 5000);
              console.log(array_command[x]); 
            }; 
          }(i), 1000);
        }
    },3000);*/
  });
}

/*function separate_command(max_index,min_index,data){
   const array_command=[];
    for(let i=min_index;i <= min_index;i++){
      min_index=data.index+1;
      //console.log("min_index",min_index);
      const command =  data.data;
      //console.log("Push data=",command);
      array_command.push(command);
      go(command);    
      //console.log(i+"\t"+command)
      if(i === max_index){
      console.log("IF CALLED AT",i)
      send_command_to_drone();
      break;
    }  
  }
}*/

const array_of_commands=[];
function go(x){
  /*console.log("GO FUNCTION CALLED");*/
  const lastIndex = array_of_commands.length - 1;
  if (array_of_commands[lastIndex] === x){
      //do nothing
      //console.log("Subsequest command omitted");
  }
  else{
    array_of_commands.push(x);
    //console.log("New_Array=",array_of_commands);
  }
}



var i=0;
async function send_command_to_drone(data){
  {
    const command = data[i];
    const delay = commandDelays[command];
    console.log("ARRAY=",data);
    //console.log("Final Array=",array_of_commands)
    drone.send(command, 0, command.length, PORT, HOST, handleError);
    console.log(`running command: ${command}`);
    console.log('done!');
    await wait(delay);
    i += 1;
    if (i < data.length) {
      return send_command_to_drone(data);
    }
    /*console.log(array_of_commands.length);
    setTimeout(function(){
      for (let i=0;i<array_of_commands.length;i++){
        drone.send(array_of_commands[i], 0, array_of_commands[i].length, PORT, HOST, handleError);
        console.log("Sleep 3 seconds")
        console.log(array_of_commands[i]); 
      }
    },3000);*/
  }
}


function parseState(state) {
  return state
    .split(';')
    .map(x => x.split(':'))
    .reduce((data, [key, value]) => {
      data[key] = value;
      return data;
    }, {});
}

drone.on('message', message => {
  console.log(`🤖 : ${message}`);
  io.sockets.emit('status', message.toString());
});

function handleError(err) {
  if (err) {
    console.log('ERROR');
    console.log(err);
  }
}

const openstream = () =>{
  try{
      console.log(`inside stream function now`);
      let websocket = 8080;
      video.on('message', (msg, rinfo) => {
      console.log(`Video stream initiated..`);
      console.log(msg);
      let buf = Buffer.from(msg);
      if(buf.indexOf(Buffer.from([0, 0, 0, 1])) != -1){//FIND IF FIRST PART OF FRAME
          counter++;
          if(counter == 3){//COLLECT 3 FRAMES AND SEND TO WEBSOCKET
              let temp = Buffer.concat(videoBuff);
              counter = 0
              websocket.clients.forEach(function each(client) {
                  if (client.readyState === WebSocket.OPEN) {
                      try {
                          client.send(temp);
                          console.log(`Video streaming now`);//SEND OVER WEBSOCKET
                      } catch(e) {
                         console.log(`Sending failed:`, e); 
                      }
                  }
              });
              videoBuff.length = 0;
              videoBuff = [];
          }
          videoBuff.push(buf);
        }
        else{
          videoBuff.push(buf);
        }
      });
    }
  catch(e)
  {
    console.log(`Error`,e);
  }  
}
video.on('listening', () => {
    let address = video.address();
    //UNCOMNET FOR DEBUG
    console.log(`Video Server listening on- ${address.address}:${address.port}`);
});
video.bind(port_video);

video.on('error', (err) => {
    console.log(`Streaming server error:\n${err.stack}`);
    video.close();
});

if (!module.parent) {
  http.createServer(accept).listen(8080);
  console.log('Socket io server up and running at port 8080');
} else {
  exports.accept = accept;
}