var dgram = require('dgram');
var wait = require('waait');
var app = require('express')();

var { spawn } = require('child_process');
var cfenv = require('cfenv').getAppEnv()
var http = require('http');
var io = require('socket.io')(http);
var throttle = require('lodash/throttle');

var PORT = 8889; //TELLO PORT
var HOST = '192.168.10.1'; //TELLO ADDRESS
var video = dgram.createSocket('udp4');// UDP SERVER IPv4 FOR RECEIVING VIDEO RAW H264 ENCODED YUV420p
var port_video = 11111;//TELLO VIDEO PORT
var port_websocket = 8080; //FOR SENDING VIDEO


var local = '127.0.0.1';
var drone = dgram.createSocket('udp4');
drone.bind(PORT);

var droneState = dgram.createSocket('udp4');
droneState.bind(8890);

var delay_between_commands = {
'wait_time': 8000
}
function send_local_command(data){
  try{
    var data_obtained = JSON.parse(data);
    var data=data_obtained.data;
    console.log("COMMANDS=",data);
    send_command_to_drone(data);
  }
catch{
  if(data == "streamon"){
    drone.send(data, 0, data.length, PORT, HOST, handleError);
    console.log(`running gamepad command: ${data}`);
    }
    else{
    drone.send(data, 0, data.length, PORT, HOST, handleError);
    console.log(`running gamepad command: ${data}`);
    }
  }
}
var i=0;
async function send_command_to_drone(data){
{
  var commands = data[i];
  if(commands === 'drone.initialize()'){
  commands = `command`;
  }
  else if(commands === 'drone.takeoff()'){
  commands = `takeoff`;
  }
  else if(commands === 'drone.land()'){
  commands = `land`;
  }
  else if(commands.slice(0,13) === `drone.forward`){
  commands = `forward 20`;
  }
  else if(commands.slice(0,11) === `drone.speed`){
  commands = `speed 20`;
  }
  else if(commands.slice(0,17) === `drone.flipforward`){
  commands = `flip f`;
  }
  else if(commands.slice(0,18) === `drone.flipbackward`){
  commands = `flip b`;
  }
  else if(commands.slice(0,15) === `drone.flipright`){
  commands = `flip r`;
  }
  else if(commands.slice(0,14) === `drone.flipleft`){
  commands = `flip l`;
  }
  else if(commands.slice(0,14) === `drone.backward`){
  commands = `backward 20`;
  }
  else if(commands.slice(0,10) === `drone.left`){
  commands = `left 20`;
  }
  else if(commands.slice(0,11) === `drone.right`){
  commands = `right 20`;
  }
  else if(commands.slice(0,10) === `drone.down`){
  commands = `down 20`;
  }
  else if(commands.slice(0,8) === `drone.up`){
  commands = `up 20`;
  }
  else if(commands.slice(0,8) === `drone.up`){
  commands = `up 20`;
  }
  else if(commands.slice(0,9) === `drone.ccw`){
  commands = `ccw 30`;
  }
  else if(commands.slice(0,8) === `drone.cw`){
  commands = `cw 30`;
  }
  else if(commands.slice(0,11) === `drone.hover`){
  commands = `stop`;
  }
  else if(commands.slice(0,10) === `drone.halt`){
  commands = `stop`;
  }
  else if(commands.slice(0,13) === `drone.forward`){
  commands = `forward`;
  }
  else if(commands.slice(0,14) === `drone.backward`){
  commands = `backward`;
  }
  else if(commands.slice(0,10) === `drone.left`){
  commands = `left`;
  }
  else if(commands.slice(0,11) === `drone.right`){
  commands = `right`;
  }
    var delay = delay_between_commands.wait_time;
    drone.send(commands, 0, commands.length, PORT, HOST, handleError);
    console.log(`running code command: ${commands}`);
    console.log("Delay=",delay,"ms");
    await wait(delay);
    i += 1;
    if (i < data.length) {
      return send_command_to_drone(data);
    }
    else{
      console.log("All Command Executed");
      i=0;
    }
  }
}
drone.on('message', message => {
  console.log(`🤖 : ${message}`);
  io.sockets.emit('status', message.toString());
});

function handleError(err) {
  if (err) {
    console.log('ERROR');
    console.log(err);
  }
}