const dgram = require('dgram');
const wait = require('waait');
const app = require('express')();
const ws = require('ws');
const wss = new ws.Server({noServer: true});
const { spawn } = require('child_process');
const cfenv = require('cfenv').getAppEnv()

const http = require('http');
const io = require('socket.io')(http);
const throttle = require('lodash/throttle');


const PORT = 8889; //TELLO PORT
const HOST = '192.168.10.1'; //TELLO ADDRESS 
const video = dgram.createSocket('udp4');// UDP SERVER IPv4 FOR RECEIVING VIDEO RAW H264 ENCODED YUV420p
const port_video = 11111;//TELLO VIDEO PORT

const port_websocket = 8080; //FOR SENDING VIDEO

//OBJ TEMP INFO
let  videoBuff = [];//VIDEO BUFFER
let  counter = 0;//COUNTER FOR VIDEO BUFFER FRAMES

const local = '127.0.0.1';

const drone = dgram.createSocket('udp4');
drone.bind(PORT);

const droneState = dgram.createSocket('udp4');
droneState.bind(8890);

const delay_between_commands = {
  'wait_time': 8000
}

function accept(req, res) {
  // all incoming requests must be websockets
  if (!req.headers.upgrade || req.headers.upgrade.toLowerCase() != 'websocket') {
    res.end();
    return;
  }

  // can be Connection: keep-alive, Upgrade
  if (!req.headers.connection.match(/\bupgrade\b/i)) {
    res.end();
    return;
  }

  wss.handleUpgrade(req, req.socket, Buffer.alloc(0), onConnect);
}


function onConnect(wss){
  wss.send('Hello from the server\'s end');
  wss.on('message',function (message) {
    //console.log("Command sent from the browser")
    try{
      const data_obtained = JSON.parse(message);
      const data=data_obtained.data;
      console.log("COMMANDS=",data);
      send_command_to_drone(data);
    }
    catch{
      if(message == "streamon"){
        drone.send(message, 0, message.length, PORT, HOST, handleError);
        console.log(`running gamepad command: ${message}`);
        openstream(wss);
      }
      else{
        drone.send(message, 0, message.length, PORT, HOST, handleError);
        console.log(`running gamepad command: ${message}`);
      }
    }
    /*const index=data_obtained.index;*/
    //console.log("Data obtained=",data_obtained);
  });
}

var i=0;
async function send_command_to_drone(data){
  {
    var commands = data[i];
    if(commands === 'drone.initialize()'){
        commands = `command`;
    }
    else if(commands === 'drone.takeoff()'){
        commands = `takeoff`;
    }
    else if(commands === 'drone.land()'){
        commands = `land`;
    }
    else if(commands.slice(0,13) === `drone.forward`){
        commands = `forward 20`;
    }
    else if(commands.slice(0,11) === `drone.speed`){
        commands = `speed 20`;
    }
    else if(commands.slice(0,17) === `drone.flipforward`){
        commands = `flip f`;
    }
    else if(commands.slice(0,18) === `drone.flipbackward`){
        commands = `flip b`;
    }
    else if(commands.slice(0,15) === `drone.flipright`){
        commands = `flip r`;
    }
    else if(commands.slice(0,14) === `drone.flipleft`){
        commands = `flip l`;
    }
    else if(commands.slice(0,14) === `drone.backward`){
        commands = `backward 20`;
    }
    else if(commands.slice(0,10) === `drone.left`){
        commands = `left 20`;
    }
    else if(commands.slice(0,11) === `drone.right`){
        commands = `right 20`;
    }
    else if(commands.slice(0,10) === `drone.down`){
        commands = `down 20`;
    }
    else if(commands.slice(0,8) === `drone.up`){
        commands = `up 20`;
    }
    else if(commands.slice(0,8) === `drone.up`){
        commands = `up 20`;
    }
    else if(commands.slice(0,9) === `drone.ccw`){
        commands = `ccw 30`;
    }
    else if(commands.slice(0,8) === `drone.cw`){
        commands = `cw 30`;
    }
    else if(commands.slice(0,11) === `drone.hover`){
        commands = `stop`;
    }
    else if(commands.slice(0,10) === `drone.halt`){
        commands = `stop`;
    }
    else if(commands.slice(0,13) === `drone.forward`){
        commands = `forward`;
    }
    else if(commands.slice(0,14) === `drone.backward`){
        commands = `backward`;
    }
    else if(commands.slice(0,10) === `drone.left`){
        commands = `left`;
    }
    else if(commands.slice(0,11) === `drone.right`){
        commands = `right`;
    }
    //const delaytime=JSON.parse(commandDelays);
    const delay = delay_between_commands.wait_time;
    //console.log(commandDelays.command)
    drone.send(commands, 0, commands.length, PORT, HOST, handleError);
    console.log(`running code command: ${commands}`);
    console.log("Delay=",delay,"ms");
    await wait(delay);
    i += 1;
    if (i < data.length) {
      return send_command_to_drone(data);
    }
    else{
    	console.log("All Command Executed");
    	i=0;
    }
  }
}

function parseState(state) {
  return state
    .split(';')
    .map(x => x.split(':'))
    .reduce((data, [key, value]) => {
      data[key] = value;
      return data;
    }, {});
}

drone.on('message', message => {
  console.log(`🤖 : ${message}`);
  io.sockets.emit('status', message.toString());
});

function handleError(err) {
  if (err) {
    console.log('ERROR');
    console.log(err);
  }
}

const openstream = (wss) =>{
    try{
        wss.broadcast = function(data) {
        wss.clients.forEach(function each(client) {
        if (client.readyState === ws.OPEN) {
          client.send(data);
        }
      })
    }

    app.post(`/index`, (req, res) => {
        res.connection.setTimeout(0)
        req.on('data', function(data) {
        console.log("broadcasting data");
        wss.broadcast(data);
      })
    })


    console.log('starting ffmpeg')
    // ffmpeg -i udp://192.168.10.1:11111 -f mpegts -codec:v mpeg1video -s 640x480 -b:v 800k -r 20 -bf 0 http://127.0.0.1:8081/tellostream
    const ffmpeg = spawn('ffmpeg', [
      '-hide_banner',
      '-i',
      `udp://${HOST}:${port_video}`,
      '-f',
      'mpegts',
      '-codec:v',
      'mpeg1video',
      '-s',
      '640x480',
      '-b:v',
      '800k',
      '-bf',
      '0',
      '-r',
      '20',
      `http://${local}:${port_websocket}/index`
    ])

    ffmpeg.stderr.on('data', data => {
      console.log(`stderr: ${data}`)
    })

    ffmpeg.on('close', code => {
      console.log(`child process exited with code ${code}`)
    })

    const exitHandler = options => {
      if (options.cleanup) {
        ffmpeg.stderr.pause()
        ffmpeg.stdout.pause()
        ffmpeg.stdin.pause()
        ffmpeg.kill()
      }
      if (options.exit) {
        process.exit()
      }
    }

    process.on('exit', exitHandler.bind(null, { cleanup: true }))
    process.on('SIGINT', exitHandler.bind(null, { exit: true }))
    process.on('SIGUSR1', exitHandler.bind(null, { exit: true }))
    process.on('SIGUSR2', exitHandler.bind(null, { exit: true }))
    process.on('uncaughtException', exitHandler.bind(null, { exit: true }))
    }
    catch(e){
        console.log("error",e);
    }
}

if (!module.parent) {
  http.createServer(accept).listen(8080);
  console.log('Socket io server up and running at port 8080');
} else {
  exports.accept = accept;
}