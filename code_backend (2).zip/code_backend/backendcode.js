const dgram = require('dgram');
const wait = require('waait');
const app = require('express')();
const ws = require('ws');
const wss = new ws.Server({noServer: true});

const http = require('http');
const io = require('socket.io')(http);
const throttle = require('lodash/throttle');
const commandDelays = require('./commandDelays');

const PORT = 8889; //TELLO PORT
const HOST = '192.168.10.1'; //TELLO ADDRESS 
const video = dgram.createSocket('udp4');// UDP SERVER IPv4 FOR RECEIVING VIDEO RAW H264 ENCODED YUV420p
const port_video = 11111;//TELLO VIDEO PORT

const port_websocket = 8080; //FOR SENDING VIDEO

//OBJ TEMP INFO
let  videoBuff = [];//VIDEO BUFFER
let  counter = 0;//COUNTER FOR VIDEO BUFFER FRAMES

const drone = dgram.createSocket('udp4');
drone.bind(PORT);

const droneState = dgram.createSocket('udp4');
droneState.bind(8890);

function accept(req, res) {
  // all incoming requests must be websockets
  if (!req.headers.upgrade || req.headers.upgrade.toLowerCase() != 'websocket') {
    res.end();
    return;
  }

  // can be Connection: keep-alive, Upgrade
  if (!req.headers.connection.match(/\bupgrade\b/i)) {
    res.end();
    return;
  }

  wss.handleUpgrade(req, req.socket, Buffer.alloc(0), onConnect);
}

function onConnect(ws){
  ws.send('Hello from the server\'s end');
  ws.on('message',function (message) {
    console.log("Command sent from the browser")
    const data=JSON.parse(message);
    const index=data.index;
    for(i=0;i<index;i++){
    	const commands = data.data ;
    	const arrray_command;
    	arrray_command.push(command);
		console.log(array_command);
    }
    /*const command=data.data;
    console.log(command);
    drone.send(command, 0, command.length, PORT, HOST, handleError);
    setTimeout(() => ws.close(1000, "Wait!"), 5000);*/
  });
}

/*function go() {
  const command = commands[i];
  const delay = commandDelays[command];
  console.log(`running command: ${command}`);
  drone.send(command, 0, command.length, PORT, HOST, handleError);
  await wait(delay);
  i += 1;
  if (i < commands.length) {
    return go();
  }
  console.log('done!');
}*/

function parseState(state) {
  return state
    .split(';')
    .map(x => x.split(':'))
    .reduce((data, [key, value]) => {
      data[key] = value;
      return data;
    }, {});
}

drone.on('message', message => {
  console.log(`🤖 : ${message}`);
  io.sockets.emit('status', message.toString());
});

function handleError(err) {
  if (err) {
    console.log('ERROR');
    console.log(err);
  }
}
